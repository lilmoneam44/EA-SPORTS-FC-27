require 'imports/core/common'
require 'imports/career_mode/enums'
require 'imports/career_mode/consts'

-- Get FCE Career Mode Manager object.
-- Type ID in lua\libs\v2\imports\career_mode\enums.lua (ENUM_FCEGameModes)
function GetManagerObjByTypeId(type_id)
    if type(type_id) ~= "number" then
        LOGGER:LogError("GetManagerObjByTypeId passed type_id is not a number!")
        return 0
    end

    local result = 0

    local comm_impl = GetPlugin(ENUM_djb2FeFceGMCommServiceInterface_CLSS)
    if (comm_impl <= 0)  then return 0 end
    
    local mode_managers = MEMORY:ReadMultilevelPointer(comm_impl, {0x20, 0x10})
    local mode_manager = mode_managers + (0x20 * type_id)
    
    -- Check if there is any instance
    if (MEMORY:ReadInt(mode_manager + 0x10) ~= 1) then
        return 0
    end
    
    local mode_manager_type = MEMORY:ReadPointer(mode_manager + 0x8)
    -- Check count
    if (MEMORY:ReadInt(mode_manager_type + 0x10) ~= 1) then
        return 0
    end
    
    result = MEMORY:ReadMultilevelPointer(mode_manager, {0x18, 0x0})

    return result
end

function SetSquadRole(playerid, role)
    print ("TODO: FC27")
    print ("NOT IMPLEMENTED SetSquadRole")
end

function GetCMEventNameByID(event_id)
    return CONST_CM_EVENTS_NAMES[event_id] or string.format("EVENT_%d", event_id)
end

function GetUserTeamID()
    if not IsInCM() then return 0 end
    
    local user_mgr = GetManagerObjByTypeId(ENUM_FCEGameModesFCECareerModeUserManager)
    local user_info = MEMORY:ReadPointer(user_mgr + 0x18)

    local teamid = MEMORY:ReadInt(user_info + 0x1F4)
    if (teamid <= 0) then teamid = 0 end
    
    return teamid
end

function GetUserNationalTeamID()
    if not IsInCM() then return 0 end

    local user_mgr = GetManagerObjByTypeId(ENUM_FCEGameModesFCECareerModeUserManager)
    local user_info = MEMORY:ReadPointer(user_mgr + 0x18)
    
    local teamid = MEMORY:ReadInt(user_info + 0x268)
    if (teamid <= 0) then teamid = 0 end
    
    return teamid
end

function IsPlayerLoanedOut(playerid)
    if IsInCM() then
        -- Check in LoansManager (In Career Mode)
        local loans_mgr = GetManagerObjByTypeId(ENUM_FCEGameModesFCECareerModeLoansManager)
        local loans_array_end = MEMORY:ReadPointer(loans_mgr + 0x48)    -- mpEnd
        local current_record = MEMORY:ReadPointer(loans_mgr + 0x40)     -- mpBegin
    
        while current_record < loans_array_end do
            local loan_playerid = MEMORY:ReadInt(current_record + 0x0)
            if playerid == loan_playerid then
                return true
            end
            current_record = current_record + 0x20  -- += sizeof(PlayerLoan)
        end
    end

    -- Check in playerloans Database table
    local playerloans_table = LE.db:GetTable("playerloans")
    local current_record = playerloans_table:GetFirstRecord()
    while current_record > 0 do
        if playerid == playerloans_table:GetRecordFieldValue(current_record, "playerid") then
            return true
        end

        current_record = playerloans_table:GetNextValidRecord()
    end
    
    return false
end

function GetUserSeniorTeamPlayerIDs()
    local result = {}
    if not IsInCM() then return result end

    local user_teamid = GetUserTeamID()

    -- From this table should be the quickest I guess
    local cm_teamsheets_table = LE.db:GetTable("cm_teamsheets")
    local current_record = cm_teamsheets_table:GetFirstRecord()
    while current_record > 0 do
        local teamid = cm_teamsheets_table:GetRecordFieldValue(current_record, "teamid")
        if teamid == user_teamid then
            for i=1,51 do
                local playerid = cm_teamsheets_table:GetRecordFieldValue(current_record, string.format("playerid%d", i))
                if (playerid > 0) then
                    result[playerid] = true
                end

                if (playerid == -1) then
                    return result
                end
            end
        end
        current_record = cm_teamsheets_table:GetNextValidRecord()
    end

    return result
end

function UserTeamSetPlayersForm(v)
    for playerid, _ in pairs(GetUserSeniorTeamPlayerIDs()) do
        SetPlayerForm(playerid, v)
    end
end

function UserTeamSetPlayersMorale(v)
    for playerid, _ in pairs(GetUserSeniorTeamPlayerIDs()) do
        SetPlayerMorale(playerid, v)
    end
end

function UserTeamSetPlayersFitness(v_fitness)
    for playerid, _ in pairs(GetUserSeniorTeamPlayerIDs()) do
        SetPlayerFitness(playerid, v_fitness)
    end
end
